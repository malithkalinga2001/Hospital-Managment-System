-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2023 at 05:18 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_information`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctortbl`
--

CREATE TABLE `doctortbl` (
  `Doctor_ID` int(15) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Phone` varchar(25) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Type` varchar(15) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctortbl`
--

INSERT INTO `doctortbl` (`Doctor_ID`, `Name`, `Phone`, `Address`, `Type`, `Password`) VALUES
(1, 'Saman', '0112233564', 'Anuradhapura', 'Specialist', 'SPass'),
(2, 'Kasun', '0251223456', 'Nuwara Eliya', 'Psychiatrist', 'KPass'),
(3, 'Janith', '0762535255', 'Ahaliyagoda', 'Surgeon', 'JPass'),
(4, 'Gayan', '0752255654', 'Kegalla', 'Sentist', 'GPass'),
(5, 'Malith', '0779930337', 'Anuradhapura', 'Surgeon', 'MPass');

-- --------------------------------------------------------

--
-- Table structure for table `parientdiagnosis`
--

CREATE TABLE `parientdiagnosis` (
  `Patient_Id` int(15) NOT NULL,
  `Symptom` varchar(200) NOT NULL,
  `Diagnosis` varchar(200) NOT NULL,
  `Medicines` varchar(200) NOT NULL,
  `WardReq` varchar(5) NOT NULL,
  `TypeWard` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parientdiagnosis`
--

INSERT INTO `parientdiagnosis` (`Patient_Id`, `Symptom`, `Diagnosis`, `Medicines`, `WardReq`, `TypeWard`) VALUES
(1, 'fever', 'viral fever', 'dcolod total', 'YES', 'Single'),
(2, 'dd', 'ddddddd', 'fefg', 'YES', 'Single'),
(3, 'Fever, Cold, Headache', 'Covid19', 'Sinopham Vaccine', 'YES', 'General'),
(22, 'qwe', 'rty', 'bnm', 'NO', ''),
(1233, 'qwwwee', 'ewrere', 'ewrerrer', 'YES', 'General');

-- --------------------------------------------------------

--
-- Table structure for table `parienttbl`
--

CREATE TABLE `parienttbl` (
  `Patient_ID` int(15) NOT NULL,
  `Name` varchar(25) NOT NULL,
  `Phone` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Age` int(15) NOT NULL,
  `Blood_Group` varchar(10) NOT NULL,
  `Major_Disease` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parienttbl`
--

INSERT INTO `parienttbl` (`Patient_ID`, `Name`, `Phone`, `Address`, `Gender`, `Age`, `Blood_Group`, `Major_Disease`) VALUES
(1, 'Kumari', '0253121451', 'ABVV', 'Female', 20, 'A+', 'No'),
(2, 'Kalinga', '0763580514', 'Horowpothana', 'Male', 27, 'A+', 'No'),
(3, 'Sithija', '0751223456', 'Migamuwa', 'Female', 22, 'AB', 'No'),
(5, 'Sithija', '0123456777', 'Polonnaruwa', 'Female', 25, 'D', 'No'),
(22, 'Kavi', '01234567', 'Kandy', 'Female', 20, 'B+', 'No'),
(125, 'Gayashan', '0775262321', 'Malabe', 'Male', 32, 'B-', 'Yes'),
(1237, 'Janith', '01234567', 'Kandy', 'Male', 23, 'B+', 'Yes'),
(1239, 'Malisha', '123456789', 'Moratuwa', 'Female', 16, 'AB+', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `patientreport`
--

CREATE TABLE `patientreport` (
  `Pat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctortbl`
--
ALTER TABLE `doctortbl`
  ADD PRIMARY KEY (`Doctor_ID`);

--
-- Indexes for table `parientdiagnosis`
--
ALTER TABLE `parientdiagnosis`
  ADD PRIMARY KEY (`Patient_Id`);

--
-- Indexes for table `parienttbl`
--
ALTER TABLE `parienttbl`
  ADD PRIMARY KEY (`Patient_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctortbl`
--
ALTER TABLE `doctortbl`
  MODIFY `Doctor_ID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `parientdiagnosis`
--
ALTER TABLE `parientdiagnosis`
  MODIFY `Patient_Id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1240;

--
-- AUTO_INCREMENT for table `parienttbl`
--
ALTER TABLE `parienttbl`
  MODIFY `Patient_ID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1240;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
